#include "stateMachine.h"

/**
 * Deals with the receiver part of the application
 * @param serialPort 
 */
void receiver(int serialPort);

